<?php
require('db.php');

if (!isset($_GET['type'])) {
    die("Invalid request");
}

$type = $_GET['type'];

// Fetch filtered data
$query = "SELECT * FROM alumni_data";
$result = mysqli_query($conn, $query);

if (!$result) {
    die("Database query failed: " . mysqli_error($conn));
}

$data = [];
while ($row = mysqli_fetch_assoc($result)) {
    $data[] = $row;
}

// Function to generate CSV
function generateCSV($data) {
    header('Content-Type: text/csv');
    header('Content-Disposition: attachment; filename="alumni_data.csv"');
    
    $output = fopen("php://output", "w");
    fputcsv($output, array_keys($data[0])); // Headers

    foreach ($data as $row) {
        fputcsv($output, $row);
    }

    fclose($output);
}

// Function to generate PDF
function generatePDF($data) {
    require('fpdf/fpdf.php'); // Make sure fpdf library is installed

    $pdf = new FPDF();
    $pdf->AddPage();
    $pdf->SetFont('Arial', 'B', 12);

    // Add headers
    foreach (array_keys($data[0]) as $header) {
        $pdf->Cell(40, 10, $header, 1);
    }
    $pdf->Ln();

    // Add rows
    foreach ($data as $row) {
        foreach ($row as $column) {
            $pdf->Cell(40, 10, $column, 1);
        }
        $pdf->Ln();
    }

    $pdf->Output("D", "alumni_data.pdf");
}

// Function to generate Word file
function generateWord($data) {
    header("Content-type: application/vnd.ms-word");
    header("Content-Disposition: attachment;Filename=alumni_data.doc");

    echo "<html><body><table border='1'>";
    echo "<tr>";
    foreach (array_keys($data[0]) as $header) {
        echo "<th>$header</th>";
    }
    echo "</tr>";

    foreach ($data as $row) {
        echo "<tr>";
        foreach ($row as $column) {
            echo "<td>$column</td>";
        }
        echo "</tr>";
    }

    echo "</table></body></html>";
}

// Choose format
if ($type === "csv") {
    generateCSV($data);
} elseif ($type === "pdf") {
    generatePDF($data);
} elseif ($type === "word") {
    generateWord($data);
} else {
    die("Invalid format requested");
}
?>
