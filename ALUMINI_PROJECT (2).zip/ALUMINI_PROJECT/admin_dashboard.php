<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Alumni Project - Admin Dashboard</title>

    <!-- Bootstrap & AdminLTE CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    
    <!-- DataTables CSS -->
    <link rel="stylesheet" href="https://cdn.datatables.net/1.13.6/css/jquery.dataTables.min.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/buttons/2.3.6/css/buttons.dataTables.min.css">

    <!-- jQuery & DataTables JS -->
    <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
    <script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/buttons/2.3.6/js/dataTables.buttons.min.js"></script>
    <script src="https://cdn.datatables.net/buttons/2.3.6/js/buttons.html5.min.js"></script>
    <script src="https://cdn.datatables.net/buttons/2.3.6/js/buttons.print.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.10.1/jszip.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.2.7/pdfmake.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.2.7/vfs_fonts.js"></script>

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/admin-lte@3.2/dist/css/adminlte.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
<style>
    body {
            background: url('login.jpg') no-repeat center center fixed;
            background-size: cover;
        }
        .content-wrapper {
            background: rgba(255, 255, 255, 0.8);
            backdrop-filter: blur(1px);
            padding: 20px;
            border-radius: 10px;
            margin: 20px;
        }
        a {
            text-decoration: none !important;
        }
    </style>
</head>
<body class="hold-transition sidebar-mini">

<div class="wrapper">
    <!-- Navbar -->
    <nav style="display: flex;justify-content: space-between;width: 85%;" class="main-header navbar navbar-expand navbar-white navbar-light">
        <ul class="navbar-nav">
            <li class="nav-item">
                <a class="nav-link" data-widget="pushmenu" href="#" role="button"><i class="fas fa-bars"></i></a>
            </li>
            <li class="nav-item d-none d-sm-inline-block">
                <a href="#" class="nav-link" id="home">Home</a>
            </li>   
        </ul>

        <!-- Right navbar links -->
        <ul class="navbar-nav ml-auto">
            <li class="nav-item">
                <a class="nav-link" href="logout.php">
                    <i class="fas fa-sign-out-alt"></i> Logout
                </a>
            </li>
        </ul>
    </nav>

    <!-- Sidebar -->
    <aside class="main-sidebar elevation-4" style="background-color: hsl(210deg 28.26% 38.11%);height: auto;">
        <a href="#" class="brand-link" style="color: white;">
            <img src="logo.png" alt="Admin Logo" class="brand-image img-circle elevation-3">
            <span style="text-decoration: none;" class="brand-text font-weight-light">Administrator</span>
        </a>
        <div style="border-top: 2px solid rgba(255, 255, 255, 0.2); margin: 0 15px;"></div>

        <div class="sidebar">
            <nav class="mt-2">
                <ul class="nav nav-pills nav-sidebar flex-column">
                    <li class="nav-item" style="color: white;">
                        <a href="#" class="nav-link load-page" data-page="upload_csv.php">
                            <i class="nav-icon fas fa-upload " style="color:white;"></i>
                            <p style="color: white;">Upload Files</p>
                        </a>
                    </li>
                    <li class="nav-item" style="color: white;">
                        <a href="#" class="nav-link load-page" data-page="filter.php">
                            <i class="nav-icon fas fa-filter " style="color:white;"></i>
                            <p style="color: white;">Filter</p>
                        </a>
                    </li>
                    <li class="nav-item" style="color: white;">
                        <a href="#" class="nav-link load-page" data-page="printfilter.php">
                            <i class="nav-icon fas fa-print" style="color:white;"> </i>
                            <p style="color: white;">Print Filter</p>
                        </a>
                    </li>
                </ul>
            </nav>
        </div>
    </aside>

    <!-- Content Wrapper -->
    <div class="content-wrapper">
        <div class="content-header">
            <div class="container-fluid">
                <h1>Welcome to the Admin Dashboard</h1>
            </div>
        </div>

        <section class="content">
            <div class="container-fluid" id="dynamic-content">
                <p>Select an option from the sidebar.</p>
            </div>
        </section>
    </div>
</div>

<!-- JavaScript -->
<script src="https://cdn.jsdelivr.net/npm/jquery@3.6.0/dist/jquery.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/admin-lte@3.2/dist/js/adminlte.min.js"></script>

<script>
$(document).ready(function() {
    // Load content dynamically
    function loadPage(pageElement) {
        var page = pageElement.data("page");

        // Update active class
        $(".load-page").removeClass("active");
        pageElement.addClass("active");

        // Load content into the #dynamic-content div
        $("#dynamic-content").load(page);
    }

    // Attach click event
    $(".load-page").click(function (e) {
        e.preventDefault();
        loadPage($(this));
    });

    // Load the first page by default on page load
    var firstPage = $(".load-page").first();
    if (firstPage.length) {
        loadPage(firstPage);
    }


    // Load home content when clicking "Home"
    $("#home").click(function(e) {
        e.preventDefault();
        $("#dynamic-content").html('<h1>Welcome to the Admin Dashboard</h1><p>Select an option from the sidebar.</p>');
        $(".load-page").removeClass("active");
    });
});
</script>

</body>
</html>
