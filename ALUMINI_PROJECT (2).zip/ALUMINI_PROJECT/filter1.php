<?php
require('db.php');
$districts_and_cities = [
    "Ariyalur" => ["Ariyalur", "Jayankondam", "Sendurai", "Udayarpalayam"],
    "Chengalpattu" => ["Chengalpattu", "Tambaram", "Pallavaram", "Madambakkam"],
    "Chennai" => ["Chennai", "Ambattur", "Avadi", "Tiruvottiyur"],
    "Coimbatore" => ["Coimbatore", "Pollachi", "Mettupalayam", "Valparai"],
    "Cuddalore" => ["Cuddalore", "Chidambaram", "Panruti", "Virudhachalam"],
    "Dharmapuri" => ["Dharmapuri", "Harur", "Palacode", "Pennagaram"],
    "Dindigul" => ["Dindigul", "Palani", "Kodaikanal", "Natham"],
    "Erode" => ["Erode", "Gobichettipalayam", "Bhavani", "Sathyamangalam"],
    "Kallakurichi" => ["Kallakurichi", "Chinnasalem", "Sankarapuram", "Ulundurpet"],
    "Kancheepuram" => ["Kancheepuram", "Sriperumbudur", "Uthiramerur", "Walajabad"],
    "Kanniyakumari" => ["Nagercoil", "Kuzhithurai", "Padmanabhapuram", "Colachel"],
    "Karur" => ["Karur", "Kulithalai", "Pugalur", "Aravakurichi"],
    "Krishnagiri" => ["Krishnagiri", "Hosur", "Uthangarai", "Pochampalli"],
    "Madurai" => ["Madurai", "Thirumangalam", "Melur", "Usilampatti"],
    "Mayiladuthurai" => ["Mayiladuthurai", "Sirkazhi", "Kuthalam", "Tharangambadi"],
    "Nagapattinam" => ["Nagapattinam", "Vedaranyam", "Kilvelur", "Thirukkuvalai"],
    "Namakkal" => ["Namakkal", "Tiruchengode", "Rasipuram", "Kumarapalayam"],
    "Nilgiris" => ["Udhagamandalam (Ooty)", "Coonoor", "Kotagiri", "Gudalur"],
    "Perambalur" => ["Perambalur", "Kunnam", "Veppanthattai", "Alathur"],
    "Pudukkottai" => ["Pudukkottai", "Aranthangi", "Alangudi", "Keeranur"],
    "Ramanathapuram" => ["Ramanathapuram", "Paramakudi", "Rameswaram", "Kamuthi"],
    "Ranipet" => ["Ranipet", "Arakkonam", "Walajah", "Sholinghur"],
    "Salem" => ["Salem", "Mettur", "Attur", "Edappadi"],
    "Sivaganga" => ["Sivaganga", "Karaikudi", "Devakottai", "Manamadurai"],
    "Tenkasi" => ["Tenkasi", "Sankarankovil", "Kadayanallur", "Shenkottai"],
    "Thanjavur" => ["Thanjavur", "Kumbakonam", "Pattukkottai", "Orathanadu"],
    "Theni" => ["Theni", "Bodinayakanur", "Periyakulam", "Cumbum"],
    "Thoothukudi" => ["Thoothukudi (Tuticorin)", "Kovilpatti", "Tiruchendur", "Sathankulam"],
    "Tiruchirappalli" => ["Tiruchirappalli (Trichy)", "Thuraiyur", "Manapparai", "Lalgudi"],
    "Tirunelveli" => ["Tirunelveli", "Palayamkottai", "Nanguneri", "Ambasamudram"],
    "Tirupathur" => ["Tirupathur", "Vaniyambadi", "Ambur", "Natrampalli"],
    "Tiruppur" => ["Tiruppur", "Avinashi", "Palladam", "Udumalaipettai"],
    "Tiruvallur" => ["Tiruvallur", "Poonamallee", "Avadi", "Gummidipoondi"],
    "Tiruvannamalai" => ["Tiruvannamalai", "Arani", "Cheyyar", "Polur"],
    "Tiruvarur" => ["Tiruvarur", "Mannargudi", "Kodavasal", "Nannilam"],
    "Vellore" => ["Vellore", "Gudiyatham", "Katpadi", "Vaniyambadi"],
    "Viluppuram" => ["Viluppuram", "Tindivanam", "Gingee", "Kallakurichi"],
    "Virudhunagar" => ["Virudhunagar", "Sivakasi", "Aruppukkottai", "Rajapalayam"]
];


$institution_degree_map = [
    "Vidyalaya High School" => ["Higher Secondary Certificate (HSC)", "Secondary School Leaving Certificate (SSLC)"],
    "Swami Shivananda Hr Sec School" => ["Higher Secondary Certificate (HSC)", "Secondary School Leaving Certificate (SSLC)"],
    "SRMV ITI" => ["Draughtsman Civil",  
"Draughtsman Mechanical",  
"Fitter",  
"Turner",  
"Machinist",  
"Mechanic Motor Vehicle",  
"Electrician",  
"Electronics Mechanic",  
"Wireman",  
"Welder"  
],
    "Sri Ramakrishna Mission Vidyalaya Polytechnic College" => [
        "Diploma in Civil Engineering",  
"Diploma in Mechanical Engineering",  
"Diploma in Electrical & Electronics Engineering",  
"Diploma in Information Technology" 
    ],
    "Sri Ramakrishna Mission Vidyalaya Institute of Agriculture and Rural Development (SRMVIARD)" => [
       "Integrated M.Sc. in Integrated Rural and Tribal Development",  
"M.A in Rural Development and Management",
"M.Sc in Rural Development and Management",  
"B.Sc. (Hons) Agriculture" ,
"Diploma in Agriculture"   

    ],
    "College of Arts and Science - Aided" => [
       "B.Com. Cooperation",  
"B.A. English Literature",  
"B.Sc. Physics",  
"B.Sc. Chemistry",  
"B.Sc. Mathematics",  
"B.Sc. Electronics & Communication Systems",  
"B.Sc. Computer Science",  
"M.Com. Cooperative Management",  
"M.Sc. Mathematics",  
"M.Sc. Physics",  
"M.Sc. Chemistry",  
"Master of Social Work",  
"Ph.D." 

    ],
    "Sri Ramakrishna Mission Vidyalaya College of Arts and Science (Autonomous) Unaided Wing" => [
       "B.Com",  
"B.Com (CA)",  
"B.Com (PA)",  
"B.Sc. Computer Science",  
"B.Sc. (Artificial Intelligence & Machine Learning)",  
"BCA (Computer Applications)",  
"B.Sc. Physical Education, Health Education, and Sports",  
"B.Sc. IT"  ,
"MCA"
    ],
    "Sri Ramakrishna Mission Vidyalaya College of Education" => [
       "Bachelor Degree in Education (B.Ed.)",  
"Master Degree in Education (M.Ed.)",  
"Ph.D. Courses"
    ],
  
    "Sri Ramakrishna Mission Vidyalaya Maruthi College of Physical Education" => [
        "B.P.E.S (Bachelor of Physical Education and Sports)",  
"B.P.Ed (Bachelor of Physical Education)",  
"M.P.Ed (Master of Physical Education)" 
    ],
    "Faculty of Disability Management and Special Education (FDMSE)" => [
       "Integrated B.Ed.-M.Ed. in Special Education (Intellectual Disability)",  
"B.Ed. in Special Education (Visual Impairment)",  
"B.Ed. in Special Education (Hearing Impairment)",  
"B.Ed. in Special Education (Intellectual Disability)",  
"M.Ed. in Special Education (Visual Impairment)",  
"M.Ed. in Special Education (Hearing Impairment)",  
"M.Ed. in Special Education (Intellectual Disability)",  
"Diploma in Special Education (Visual Impairment)",  
"Diploma in Special Education (Hearing Impairment)",  
"Diploma in Special Education (Intellectual Disability)",  
"Diploma in Indian Sign Language Interpretation",  
"Ph.D. in Special Education (Visual Impairment, Hearing Impairment, and Intellectual Disability)"
    ],
    "Faculty of Disability Management and Special Education" => [
        "B.Sc Special Education & Rehabilitation Science",
        "B.Ed Special Education",
        "M.Ed Special Education"
    ],
    "Faculty of General and Adapted Physical Education and Yoga (GAPEY)" => [
"Bachelor of Science in Physical Education, Health Education, and Sports (B.Sc. PHS)",  
"Bachelor of Physical Education (B.P.Ed)",  
"Master of Physical Education (M.P.Ed)",  
"Ph.D. in Physical Education"  
    ]
];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Alumni Data Portal</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.datatables.net/1.13.4/css/jquery.dataTables.min.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/buttons/2.3.6/css/buttons.dataTables.min.css">
    <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
    <script src="https://cdn.datatables.net/1.13.4/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/buttons/2.3.6/js/dataTables.buttons.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.10.1/jszip.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.36/pdfmake.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.36/vfs_fonts.js"></script>
    <script src="https://cdn.datatables.net/buttons/2.3.6/js/buttons.html5.min.js"></script>
    <script src="https://cdn.datatables.net/buttons/2.3.6/js/buttons.print.min.js"></script>
</head>

<body>
<div class="container mt-4">
    <div class="card">
        <div class="card-header d-flex justify-content-between">
            <h3>Alumni Records</h3>
        </div>
        <div class="card-body">
            <form id="filterForm" class="row g-3">
                <div class="col-md-3">
                    <label for="district" class="form-label">District</label>
                    <select id="district" name="district" class="form-select">
                        <option value="">Select District</option>
                        <?php foreach ($districts_and_cities as $district => $cities) {
                            echo "<option value=\"$district\">$district</option>";
                        } ?>
                    </select>
                </div>

                <div class="col-md-3">
                    <label for="city" class="form-label">City</label>
                    <select id="city" name="city" class="form-select">
                        <option value="">Select City</option>
                    </select>
                </div>

                <div class="col-md-3">
                    <label for="institute_name" class="form-label">Institution</label>
                    <select id="institute_name" name="institute_name" class="form-select">
                        <option value="">Select Institution</option>
                        <?php foreach (array_keys($institution_degree_map) as $institute) {
                            echo "<option value=\"$institute\">$institute</option>";
                        } ?>
                    </select>
                </div>

                <div class="col-md-3">
                    <label for="degree" class="form-label">Degree</label>
                    <select id="degree" name="degree" class="form-select">
                        <option value="">Select Degree</option>
                    </select>
                </div>

                <div class="col-md-3">
                    <label for="joined_year" class="form-label">Joined Year</label>
                    <input type="number" id="joined_year" name="joined_year" class="form-control" placeholder="Enter Joined Year">
                </div>
                <div class="col-md-3">
                    <label for="completed_year" class="form-label">Completed Year</label>
                    <input type="number" id="completed_year" name="completed_year" class="form-control" placeholder="Enter Completed Year">
                </div>

                <div class="col-md-12 text-end">
                    <button type="button" id="applyFilter" class="btn btn-success">Apply Filter</button>
                </div>
            </form>

            <hr>
            <div id="resultsContainer"></div>
        </div>
    </div>
</div>

<script>
$(document).ready(function () {
    let districtsAndCities = <?php echo json_encode($districts_and_cities); ?>;
    let institutionDegreeMap = <?php echo json_encode($institution_degree_map); ?>;

    $("#district").change(function () {
        let selectedDistrict = $(this).val();
        let cityDropdown = $("#city");
        cityDropdown.empty().append("<option value=''>Select City</option>");
        if (selectedDistrict && districtsAndCities[selectedDistrict]) {
            districtsAndCities[selectedDistrict].forEach(city => {
                cityDropdown.append(`<option value="${city}">${city}</option>`);
            });
        }
    });

    $("#institute_name").change(function () {
        let selectedInstitute = $(this).val();
        let degreeDropdown = $("#degree");
        degreeDropdown.empty().append("<option value=''>Select Degree</option>");
        if (selectedInstitute && institutionDegreeMap[selectedInstitute]) {
            institutionDegreeMap[selectedInstitute].forEach(degree => {
                degreeDropdown.append(`<option value="${degree}">${degree}</option>`);
            });
        }
    });

    function fetchResults() {
    let hasFilter = false;
    
    // Check if any filter field has a value
    $("#filterForm").find("select, input").each(function () {
        if ($(this).val().trim() !== "") {
            hasFilter = true;
            return false; // Exit loop early if at least one filter is selected
        }
    });

    // If no filters are selected, show an alert and return
    if (!hasFilter) {
        alert("Please select at least one filter criteria before applying the filter.");
        return;
    }

    let formData = $("#filterForm").serialize();
    $.ajax({
        url: "fetch_data.php",
        type: "POST",
        data: formData,
        dataType: "json",
        success: function (response) {
            let table = `<table id='example2' class='table table-bordered'><thead>
                <tr>
                    <th>ID</th>
                    <th>Register Number</th>
                    <th>Student Name</th>
                    <th>DOB</th>
                    <th>Gender</th>
                    <th>Father's Name</th>
                    <th>Door No</th>
                    <th>Address Line 1</th>
                    <th>Address Line 2</th>
                    <th>Pincode</th>
                    <th>City</th>
                    <th>District</th>
                    <th>State</th>
                    <th>Institute Name</th>
                    <th>Degree</th>
                    <th>Joined Year</th>
                    <th>Completed Year</th>
                    <th>Mobile</th>
                    <th>Email</th>
                </tr></thead><tbody>`;

            response.forEach(row => {
                table += `<tr>
                    <td>${row.id}</td>
                    <td>${row.register_number}</td>
                    <td>${row.student_name}</td>
                    <td>${row.date_of_birth}</td>
                    <td>${row.gender}</td>
                    <td>${row.father_name}</td>
                    <td>${row.door_house_no}</td>
                    <td>${row.address_line1}</td>
                    <td>${row.address_line2}</td>
                    <td>${row.pincode}</td>
                    <td>${row.city}</td>
                    <td>${row.district}</td>
                    <td>${row.state}</td>
                    <td>${row.institute_name}</td>
                    <td>${row.completed_course}</td>
                    <td>${row.joined_year}</td>
                    <td>${row.completed_year}</td>
                    <td>${row.mobile_whatsapp}</td>
                    <td>${row.email_id}</td>
                </tr>`;
            });

            table += `</tbody></table>`;
            $("#resultsContainer").html(table);

            // Initialize DataTable AFTER inserting table
            $('#example2').DataTable({
                dom: 'Bfrtip',
                scrollX: true,
                autoWidth: false,
                buttons: ['copy', 'excel', 'pdf', 'print']
            });
        }
    });
}


    $("#applyFilter").click(fetchResults);
});
</script>
</body>
</html>
