<?php
$conn = new mysqli("localhost", "root", "", "file_upload_db");

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

try {
    if ($_FILES['csv_file']['error'] !== 0) {
        throw new Exception("File upload error.");
    }

    $filename = $_FILES['csv_file']['tmp_name'];
    $file = fopen($filename, "r");
    
    if (!$file) {
        throw new Exception("Failed to open the CSV file.");
    }

    fgetcsv($file); // Skip header row
    $inserted = 0;
    $skipped = 0;

    while (($row = fgetcsv($file)) !== FALSE) {
        // Convert date_of_birth from d/m/yy to yy/mm/dd
        // $dob = date_create_from_format("d/m/y", $row[2]); // CSV format: d/m/yy
        // if ($dob) {
        //     $row[2] = date_format($dob, "y/m/d"); // Convert to yy/mm/dd
        // } else {
        //     $row[2] = NULL; // Handle invalid dates
        // }

        // Check if register_number already exists
        $checkStmt = $conn->prepare("SELECT COUNT(*) FROM alumni_data WHERE register_number = ?");
        if (!$checkStmt) {
            throw new Exception("SQL Error: " . $conn->error);
        }
        $checkStmt->bind_param("s", $row[0]); // register_number is assumed to be in column 0
        $checkStmt->execute();
        $checkStmt->bind_result($count);
        $checkStmt->fetch();
        $checkStmt->close();

        if ($count > 0) {
            $skipped++;
            continue; // Skip duplicate register_number entries
        }

        // Insert new record (email is allowed to be duplicate)
        $stmt = $conn->prepare("INSERT INTO alumni_data (
            register_number, student_name, date_of_birth, gender, father_name,
            door_house_no, address_line1, address_line2, pincode, city, district,
            state, institute_name, completed_course, joined_year, completed_year,
            mobile_whatsapp, email_id
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");

        if (!$stmt) {
            throw new Exception("SQL Error: " . $conn->error);
        }

        $stmt->bind_param("ssssssssssssssiiis", ...$row);
        
        if (!$stmt->execute()) {
            throw new Exception("Insert Error: " . $stmt->error);
        }

        $inserted++;
    }
    fclose($file);

    echo "<p style='color:green;'>Successfully inserted $inserted records.</p>";
    if ($skipped > 0) {
        echo "<p style='color:orange;'>Skipped $skipped duplicate entries for register numbers.</p>";
    }
} catch (Exception $e) {
    echo "<p style='color:red;'>Error: " . $e->getMessage() . "</p>";
}

$conn->close();
?>
