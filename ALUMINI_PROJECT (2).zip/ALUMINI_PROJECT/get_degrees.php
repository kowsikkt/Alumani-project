<?php
include "db.php";

if (isset($_POST['institution_id'])) {
    $institution_name = $_POST['institution_id']; // This should be the institution name

    // Fetch institution_id based on institution name
    $stmt = $conn->prepare("SELECT id FROM institutions WHERE name = ?");
    $stmt->bind_param("s", $institution_name);
    $stmt->execute();
    $result = $stmt->get_result();
    $institution = $result->fetch_assoc();
    $stmt->close();

    if ($institution) {
        $institution_id = $institution['id'];

        // Fetch degrees based on institution_id
        $stmt = $conn->prepare("SELECT * FROM degrees WHERE institution_id = ?");
        $stmt->bind_param("i", $institution_id);
        $stmt->execute();
        $result = $stmt->get_result();

        echo '<option value="">Select Degree</option>';
        while ($row = $result->fetch_assoc()) {
            echo "<option value='{$row['id']}'>{$row['name']}</option>";
        }

        $stmt->close();
    } else {
        echo '<option value="">No degrees found</option>';
    }
} else {
    echo '<option value="">Invalid request</option>';
}
?>
