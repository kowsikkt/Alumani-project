<?php
session_start();
$filteredData = isset($_SESSION['filtered_data']) ? $_SESSION['filtered_data'] : [];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Print Filtered Data</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <style>
        .label-container {
            padding: 20px;
            border: 1px solid #000;
            margin: 10px 0;
        }
    </style>
</head>
<body>
    <div class="wrapper">
        <aside class="main-sidebar elevation-4" style="background-color: hsl(210deg 28.26% 38.11%);">
            <a href="#" class="brand-link">
                <span class="brand-text font-weight-light">Admin Dashboard</span>
            </a>
            <div class="sidebar">
                <nav class="mt-2">
                    <ul class="nav nav-pills nav-sidebar flex-column" role="menu">
                        <li class="nav-item">
                            <a href="upload.php" class="nav-link">
                                <p>Upload Files</p>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="filter.php" class="nav-link">
                                <p>Filter</p>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="printfilter.php" class="nav-link">
                                <p>Print Filter</p>
                            </a>
                        </li>
                    </ul>
                </nav>
            </div>
        </aside>
        <div class="content-wrapper">
            <div class="container mt-5">
                <h2>Filtered Data</h2>
                <button class="btn btn-success" onclick="window.print()">Print</button>
                <div class="mt-3">
                    <?php if (!empty($filteredData)) : ?>
                        <?php foreach ($filteredData as $data) : ?>
                            <div class="label-container">
                                <p><strong>Full Name:</strong> <?= $data['Full Name'] ?></p>
                                <p><strong>Father's Name:</strong> <?= $data["Father's Name"] ?></p>
                                <p><strong>Gender:</strong> <?= $data['Gender'] ?></p>
                                <p><strong>Email:</strong> <?= $data['Email'] ?></p>
                                <p><strong>Mobile:</strong> <?= $data['Mobile'] ?></p>
                                <p><strong>City:</strong> <?= $data['City'] ?></p>
                                <p><strong>District:</strong> <?= $data['District'] ?></p>
                                <p><strong>State:</strong> <?= $data['State'] ?></p>
                                <p><strong>Pincode:</strong> <?= $data['Pincode'] ?></p>
                                <p><strong>Institute:</strong> <?= $data['Institute'] ?></p>
                                <p><strong>Degree:</strong> <?= $data['Degree'] ?></p>
                                <p><strong>Joined Year:</strong> <?= $data['Joined Year'] ?></p>
                                <p><strong>Completed Year:</strong> <?= $data['Completed Year'] ?></p>
                            </div>
                        <?php endforeach; ?>
                    <?php else : ?>
                        <p>No data available.</p>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
