<?php
include "db.php";

if (isset($_POST['district_id'])) {
    $district_id = $_POST['district_id'];

    // Use prepared statement to prevent SQL injection
    $stmt = $conn->prepare("SELECT id FROM districts WHERE name = ?");
    $stmt->bind_param("s", $district_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $sel = $result->fetch_assoc();
    $stmt->close();

    if ($sel) {
        $id = $sel['id'];

        // Fetch cities based on district_id
        $stmt = $conn->prepare("SELECT * FROM cities WHERE district_id = ?");
        $stmt->bind_param("i", $id);
        $stmt->execute();
        $result = $stmt->get_result();

        echo '<option value="">Select City</option>';
        while ($row = $result->fetch_assoc()) {
            echo "<option value='{$row['name']}'>{$row['name']}</option>";
        }

        $stmt->close();
    } else {
        echo '<option value="">No cities found</option>';
    }
} else {
    echo '<option value="">Invalid request</option>';
}
?>
