<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Upload Alumni Data</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
</head>
<body class="bg-light">
    <div class="container mt-5">
        <div class="card shadow-lg p-4">
            <h2 class="text-center mb-4">Upload Alumni Data (CSV)</h2>
            <form id="uploadForm" enctype="multipart/form-data" class="text-center">
                <input type="file" name="csv_file" id="csv_file" accept=".csv" class="form-control mb-3" required>
                <button type="submit" class="btn btn-primary">Upload</button>
            </form>
            <div class="text-center mt-3">
                <a href="alumni_data_sample.csv" download class="btn btn-success">Download Sample CSV</a>
            </div>
            <div id="response" class="mt-3 text-center"></div>
        </div>
    </div>
    
    <script>
        $(document).ready(function () {
            $("#uploadForm").on("submit", function (e) {
                e.preventDefault();
                var formData = new FormData(this);
                
                $.ajax({
                    url: "upload.php",
                    type: "POST",
                    data: formData,
                    contentType: false,
                    processData: false,
                    beforeSend: function () {
                        $("#response").html("<div class='text-info'>Uploading...</div>");
                    },
                    success: function (response) {
                        $("#response").html(response);
                    }
                });
            });
        });
    </script>
</body>
</html>
