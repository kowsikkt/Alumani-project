<?php
require('db.php');

$query = "SELECT * FROM alumni_data WHERE 1";
$params = [];
$types = "";

if (!empty($_POST['institute'])) {
    $query .= " AND institute_name = ?";
    $params[] = $_POST['institute'];
    $types .= "s";
}
if (!empty($_POST['district'])) {
    $query .= " AND district = ?";
    $params[] = $_POST['district'];
    $types .= "s";
}
if (!empty($_POST['city'])) {
    $query .= " AND city = ?";
    $params[] = $_POST['city'];
    $types .= "s";
}
if (!empty($_POST['degree'])) {
    $query .= " AND completed_degree = ?";
    $params[] = $_POST['degree'];
    $types .= "s";
}
if (!empty($_POST['joined_year'])) {
    $query .= " AND joined_year = ?";
    $params[] = $_POST['joined_year'];
    $types .= "s";
}
if (!empty($_POST['completed_year'])) {
    $query .= " AND completed_year = ?";
    $params[] = $_POST['completed_year'];
    $types .= "s";
}

$stmt = $conn->prepare($query);
if (!empty($params)) {
    $stmt->bind_param($types, ...$params);
}

$stmt->execute();
$result = $stmt->get_result();

$data = [];
while ($row = $result->fetch_assoc()) {
    $data[] = $row;
}

header('Content-Type: application/json');
echo json_encode(empty($data) ? ["message" => "No data found"] : $data);
?>
