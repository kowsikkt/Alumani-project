<?php
require('db.php');

$conditions = [];
$params = [];

foreach ($_POST as $field => $value) {
    if (!empty($value)) {
        $conditions[] = "`$field` = ?";
        $params[] = $value;
    }
}

$query = "SELECT * FROM `alumni_data`";
if (!empty($conditions)) {
    $query .= " WHERE " . implode(" AND ", $conditions);
}

$stmt = $conn->prepare($query);

if (!empty($params)) {
    $types = str_repeat("s", count($params));
    $stmt->bind_param($types, ...$params);
}

$stmt->execute();
$result = $stmt->get_result();

$data = [];
while ($row = $result->fetch_assoc()) {
    $data[] = $row;
}

$stmt->close();
$conn->close();

echo json_encode($data);
?>
