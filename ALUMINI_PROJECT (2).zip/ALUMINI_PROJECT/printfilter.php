<?php
require('db.php');

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Alumni Data Portal</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.datatables.net/1.13.4/css/jquery.dataTables.min.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/buttons/2.3.6/css/buttons.dataTables.min.css">
    <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
    <script src="https://cdn.datatables.net/1.13.4/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/buttons/2.3.6/js/dataTables.buttons.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.10.1/jszip.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.36/pdfmake.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.36/vfs_fonts.js"></script>
    <script src="https://cdn.datatables.net/buttons/2.3.6/js/buttons.html5.min.js"></script>
    <script src="https://cdn.datatables.net/buttons/2.3.6/js/buttons.print.min.js"></script>
</head>
<body>
      <script type="text/javascript">    
$(document).ready(function () {
        $("#district").change(function () {

        let districtId = $(this).val();
        $.ajax({
            url: "get_cities.php",
            method: "POST",
            data: { district_id: districtId },
            success: function (response) {
                $("#city").html(response);
            }
        });
    });

    $("#institute_name").change(function () {
        let instituteId = $(this).val();
        $.ajax({
            url: "get_degrees.php",
            method: "POST",
            data: { institution_id: instituteId },
            success: function (response) {
                $("#degree").html(response);
            }
        });
    });
});

</script>
<div class="container mt-4">
    <div class="card">
        <div class="card-header"><h3>Alumni Records</h3></div>
        <div class="card-body">
            <form id="filterForm" class="row g-3">
                 <div class="col-md-3">
    <label for="district" class="form-label">District</label>
    <select id="district" name="district" class="form-select">
        <option value="">Select District</option>
        <?php
        $result = $conn->query("SELECT * FROM districts");
        while ($row = $result->fetch_assoc()) {
            echo "<option value='{$row['name']}'>{$row['name']}</option>";
        }
        ?>
    </select>
</div>

<div class="col-md-3">
    <label for="city" class="form-label">City</label>
    <select id="city" name="city" class="form-select">
        <option value="">Select City</option>
    </select>
</div>

<div class="col-md-3">
    <label for="institute_name" class="form-label">Institution</label>
    <select id="institute_name" name="institute_name" class="form-select">
        <option value="">Select Institution</option>
        <?php
        $result = $conn->query("SELECT * FROM institutions");
        while ($row = $result->fetch_assoc()) {
            echo "<option value='{$row['name']}'>{$row['name']}</option>";
        }
        ?>
    </select>
</div>

<div class="col-md-3">
    <label for="degree" class="form-label">Degree</label>
    <select id="degree" name="degree" class="form-select">
        <option value="">Select Degree</option>
    </select>
</div>


                <div class="col-md-3">
                    <label for="joined_year" class="form-label">Joined Year</label>
                    <input type="number" id="joined_year" name="joined_year" class="form-control">
                </div>
                <div class="col-md-3">
                    <label for="completed_year" class="form-label">Completed Year</label>
                    <input type="number" id="completed_year" name="completed_year" class="form-control">
                </div>

                <div class="col-md-12 text-end">
                    <button type="button" id="applyFilter" class="btn btn-success">Apply Filter</button>
                    <button type="button" id="printResults" class="btn btn-primary">Print </button>
                    <button type="button" id="downloadPDF" class="btn btn-danger">Download PDF</button>
                </div>
            </form>
            <hr>
            <div id="resultsContainer"></div>
        </div>
    </div>
</div>

<script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js"></script>
<script>
$(document).ready(function () {
    let districtsAndCities = <?php echo json_encode($districts_and_cities); ?>;
    let institutionDegreeMap = <?php echo json_encode($institution_degree_map); ?>;

    // $("#district").change(function () {
    //     let selectedDistrict = $(this).val();
    //     let cityDropdown = $("#city").empty().append("<option value=''>Select City</option>");
    //     if (selectedDistrict && districtsAndCities[selectedDistrict]) {
    //         districtsAndCities[selectedDistrict].forEach(city => {
    //             cityDropdown.append(`<option value="${city}">${city}</option>`);
    //         });
    //     }
    // });

    // $("#institute_name").change(function () {
    //     let selectedInstitute = $(this).val();
    //     let degreeDropdown = $("#degree").empty().append("<option value=''>Select Degree</option>");
    //     if (selectedInstitute && institutionDegreeMap[selectedInstitute]) {
    //         institutionDegreeMap[selectedInstitute].forEach(degree => {
    //             degreeDropdown.append(`<option value="${degree}">${degree}</option>`);
    //         });
    //     }
    // });

    $("#applyFilter").click(function () {
    let district = $("#district").val();
    let city = $("#city").val();
    let institute = $("#institute_name").val();
    let degree = $("#degree").val();
    let joinedYear = $("#joined_year").val();
    let completedYear = $("#completed_year").val();

    // Check if at least one filter is selected
    if (!district && !city && !institute && !degree && !joinedYear && !completedYear) {
        alert("Please select at least one filter criteria.");
        return;
    }

    var filterData = $("#filterForm").serialize();
    $.ajax({
        url: "fetch_data.php",
        type: "POST",
        data: filterData,
        dataType: "json",
        success: function (response) {
            $("#resultsContainer").empty();
            if (response.length > 0) {
                response.forEach(function (row) {
                    $("#resultsContainer").append(
                        `<div class="card p-3 mb-3">
                            <p><strong>Name:</strong> ${row.student_name}</p>
                            <p><strong>City:</strong> ${row.city}</p>
                            <p><strong>District:</strong> ${row.district}</p>
                            <p><strong>Institute:</strong> ${row.institute_name}</p>
                            <p><strong>Degree:</strong> ${row.completed_course}</p>
                            <p><strong>Joined Year:</strong> ${row.joined_year}</p>
                            <p><strong>Completed Year:</strong> ${row.completed_year}</p>
                        </div>`
                    );
                });
            } else {
                $("#resultsContainer").append("<p class='text-center'>No records found</p>");
            }
        }
    });
});


    // Print results
    $("#printResults").click(function () {
        var printContent = document.getElementById("resultsContainer").innerHTML;
        if (printContent.trim() === "") {
            alert("No records to print.");
            return;
        }
        var newWindow = window.open("", "", "width=800,height=600");
        newWindow.document.write("<html><head><title>Alumni Records</title></head><body>");
        newWindow.document.write("<h2>Alumni Records</h2>");
        newWindow.document.write(printContent);
        newWindow.document.write("</body></html>");
        newWindow.document.close();
        newWindow.print();
    });

    // Download results as PDF
    $("#downloadPDF").click(function () {
        var { jsPDF } = window.jspdf;
        let doc = new jsPDF();
        let content = document.querySelectorAll("#resultsContainer .card");
        let y = 20; 
        let pageHeight = doc.internal.pageSize.height;
        let pageWidth = doc.internal.pageSize.width;

        if (content.length === 0) {
            alert("No records to download.");
            return;
        }

        doc.setFont("helvetica", "bold");
        doc.text("Alumni Records", 10, 10);
        doc.setFont("helvetica", "normal");

        content.forEach((card, index) => {
            let text = card.innerText;
            let splitText = doc.splitTextToSize(text, pageWidth - 30); 
            let boxHeight = splitText.length * 7 + 10; 

            if (y + boxHeight > pageHeight - 10) {
                doc.addPage();
                y = 20; 
            }

            doc.rect(10, y - 5, pageWidth - 20, boxHeight);
            doc.text(splitText, 15, y);
            y += boxHeight + 5; 
        });

        doc.save("Alumni_Records.pdf");
    });
});
</script>
</body>
</html>
