<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Alumni Project - User Dashboard</title>
    <style>
        
          a{
        text-decoration: none !important;
    }

    .container {
            max-width: 95%;
            background: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.1);
            margin: auto;
        }
        h2 {
            text-align: center;
        }
        .filter-form {
            display: flex;
            flex-wrap: wrap;
            gap: 10px;
            align-items: center;
            justify-content: center;
            padding: 10px 0;
        }
        select, button {
            padding: 10px;
            border-radius: 5px;
            border: 1px solid #ccc;
            font-size: 16px;
        }
        select {
            width: 180px;
            background: #f8f8f8;
        }
        button {
            background-color: #007BFF;
            color: white;
            border: none;
            cursor: pointer;
            padding: 10px 15px;
        }
        button:hover {
            background-color: #0056b3;
        }
        #filteredResults {
            margin-top: 20px;
            display: none;
        }
        .table-container {
            width: 100%;
            overflow-x: auto;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 10px;
            background: white;
        }
        th, td {
            padding: 12px;
            text-align: center;
            border: 1px solid #ddd;
        }
        th {
            background-color: #007BFF;
            color: white;
        }
    </style>
     <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    
    <!-- DataTables CSS -->
    <link rel="stylesheet" href="https://cdn.datatables.net/1.13.6/css/jquery.dataTables.min.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/buttons/2.3.6/css/buttons.dataTables.min.css">

    <!-- jQuery & DataTables JS -->
    <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
    <script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/buttons/2.3.6/js/dataTables.buttons.min.js"></script>
    <script src="https://cdn.datatables.net/buttons/2.3.6/js/buttons.html5.min.js"></script>
    <script src="https://cdn.datatables.net/buttons/2.3.6/js/buttons.print.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.10.1/jszip.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.2.7/pdfmake.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.2.7/vfs_fonts.js"></script>

    <!-- Bootstrap & AdminLTE CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/admin-lte@3.2/dist/css/adminlte.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body class="hold-transition sidebar-mini">
<style>
    body {
            background: url('login.jpg') no-repeat center center fixed;
            background-size: cover;
        }
        .content-wrapper {
            background: rgba(255, 255, 255, 0.8);
            backdrop-filter: blur(1px);
            padding: 20px;
            border-radius: 10px;
            margin: 20px;
        }
        a {
            text-decoration: none !important;
        }
    </style>

<div class="wrapper">
    <!-- Navbar -->
    <nav style="display: flex;justify-content: space-between;width: 85%;" class="main-header navbar navbar-expand navbar-white navbar-light">
    <ul class="navbar-nav">
            <li class="nav-item">
                <a class="nav-link" data-widget="pushmenu" href="#" role="button"><i class="fas fa-bars"></i></a>
            </li>
            <li class="nav-item d-none d-sm-inline-block">
                <a href="#" class="nav-link" id="home">Home</a>
            </li>   
        </ul>

        <!-- Right navbar links -->
        <ul class="navbar-nav ml-auto">
            <li class="nav-item">
                <a class="" href="logout.php">
                    <i class="fas fa-sign-out-alt"></i> Logout
                </a>
            </li>
        </ul>
    </nav>

    <!-- Sidebar -->
    <aside class="main-sidebar elevation-4" style="background-color: #1E3A5F;">
    <a href="#" class="brand-link d-flex align-items-center px-3 py-3 text-white" style="text-decoration: none;">
        <img src="logo.png" alt="Admin Logo" class="brand-image img-circle elevation-3" style="width: auto; height: 40px;">
        <span class="brand-text font-weight-bold ms-2">Administrator</span>
    </a>

    <!-- Separator Line -->
    <div style="border-top: 2px solid rgba(255, 255, 255, 0.2); margin: 0 15px;"></div>

    <div class="sidebar mt-3">
        <nav>
            <ul class="nav nav-pills nav-sidebar flex-column">
                <li class="nav-item">
                    <a href="#" class="nav-link load-page" data-page="filter1.php"
                        style="color: white; display: flex; align-items: center; padding: 10px 15px; transition: 0.3s;">
                        <i class="nav-icon fas fa-filter me-2"></i>
                        <span>Filter</span>
                    </a>
                </li>
                <li class="nav-item">
                    <a href="#" class="nav-link load-page" data-page="printfilter.php"
                        style="color: white; display: flex; align-items: center; padding: 10px 15px; transition: 0.3s;">
                        <i class="nav-icon fas fa-print me-2"></i>
                        <span>Print Filter</span>
                    </a>
                </li>
            </ul>
        </nav>
    </div>
</aside>

<!-- Sidebar Hover Effect -->
<style>
    .nav-link {
        border-radius: 5px;
    }

    .nav-link:hover {
        background-color: rgba(255, 255, 255, 0.1);
        transition: background-color 0.3s ease-in-out;
    }

    .nav-icon {
        font-size: 18px;
    }
</style>

    <!-- Content Wrapper -->
    <div class="content-wrapper">
        <div class="content-header">
           
        </div>

        <section class="content">
            <div class="container-fluid" id="dynamic-content">
                <p>Select an option from the sidebar.</p>
            </div>
        </section>
    </div>
</div>

<!-- JavaScript -->
<script src="https://cdn.jsdelivr.net/npm/jquery@3.6.0/dist/jquery.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/admin-lte@3.2/dist/js/adminlte.min.js"></script>

<script>
$(document).ready(function() {
    // Load content dynamically
    function loadPage(pageElement) {
        var page = pageElement.data("page");

        // Update active class
        $(".load-page").removeClass("active");
        pageElement.addClass("active");

        // Load content into the #dynamic-content div
        $("#dynamic-content").load(page);
    }

    // Attach click event
    $(".load-page").click(function (e) {
        e.preventDefault();
        loadPage($(this));
    });

    // Load the first page by default on page load
    var firstPage = $(".load-page").first();
    if (firstPage.length) {
        loadPage(firstPage);
    }


    // Load home content when clicking "Home"
    $("#home").click(function(e) {
        e.preventDefault();
        $("#dynamic-content").html('<h1>Welcome to the Admin Dashboard</h1><p>Select an option from the sidebar.</p>');
        $(".load-page").removeClass("active");
    });
});
</script>

</body>
</html>