<?php
require('db.php');

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Alumni Data Portal</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.datatables.net/1.13.4/css/jquery.dataTables.min.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/buttons/2.3.6/css/buttons.dataTables.min.css">
    <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
    <script src="https://cdn.datatables.net/1.13.4/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/buttons/2.3.6/js/dataTables.buttons.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.10.1/jszip.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.36/pdfmake.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.36/vfs_fonts.js"></script>
    <script src="https://cdn.datatables.net/buttons/2.3.6/js/buttons.html5.min.js"></script>
    <script src="https://cdn.datatables.net/buttons/2.3.6/js/buttons.print.min.js"></script>
</head>

<body>
    <script type="text/javascript">    

</script>
<div class="container mt-4">
    <div class="card">
        <div class="card-header d-flex justify-content-between">
            <h3>Alumni Records</h3>
        </div>
        <div class="card-body">
            <form id="filterForm" class="row g-3">
                <div class="col-md-3">
    <label for="district" class="form-label">District</label>
    <select id="district" name="district" class="form-select">
        <option value="">Select District</option>
        <?php
        $result = $conn->query("SELECT * FROM districts");
        while ($row = $result->fetch_assoc()) {
            echo "<option value='{$row['name']}'>{$row['name']}</option>";
        }
        ?>
    </select>
</div>

<div class="col-md-3">
    <label for="city" class="form-label">City</label>
    <select id="city" name="city" class="form-select">
        <option value="">Select City</option>
    </select>
</div>

<div class="col-md-3">
    <label for="institute_name" class="form-label">Institution</label>
    <select id="institute_name" name="institute_name" class="form-select">
        <option value="">Select Institution</option>
        <?php
        $result = $conn->query("SELECT * FROM institutions");
        while ($row = $result->fetch_assoc()) {
            echo "<option value='{$row['name']}'>{$row['name']}</option>";
        }
        ?>
    </select>
</div>

<div class="col-md-3">
    <label for="degree" class="form-label">Degree</label>
    <select id="degree" name="degree" class="form-select">
        <option value="">Select Degree</option>
    </select>
</div>

                <div class="col-md-3">
                    <label for="joined_year" class="form-label">Joined Year</label>
                    <input type="number" id="joined_year" name="joined_year" class="form-control" placeholder="Enter Joined Year">
                </div>
                <div class="col-md-3">
                    <label for="completed_year" class="form-label">Completed Year</label>
                    <input type="number" id="completed_year" name="completed_year" class="form-control" placeholder="Enter Completed Year">
                </div>

                <div class="col-md-12 text-end">
                    <button type="button" id="applyFilter" class="btn btn-success">Apply Filter</button>
                </div>
            </form>

            <hr>
            <div id="resultsContainer"></div>
        </div>
    </div>
</div>
<script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>

<script>
    $(document).ready(function () {
        $("#district").change(function () {

        let districtId = $(this).val();
        $.ajax({
            url: "get_cities.php",
            method: "POST",
            data: { district_id: districtId },
            success: function (response) {
                $("#city").html(response);
            }
        });
    });

    $("#institute_name").change(function () {
        let instituteId = $(this).val();
        $.ajax({
            url: "get_degrees.php",
            method: "POST",
            data: { institution_id: instituteId },
            success: function (response) {
                $("#degree").html(response);
            }
        });
    });
});

$(document).ready(function () {
    let districtsAndCities = <?php echo json_encode($districts_and_cities); ?>;
    let institutionDegreeMap = <?php echo json_encode($institution_degree_map); ?>;


    function fetchResults() {
    let hasFilter = false;
    
    // Check if any filter field has a value
    $("#filterForm").find("select, input").each(function () {
        if ($(this).val().trim() !== "") {
            hasFilter = true;
            return false; // Exit loop early if at least one filter is selected
        }
    });

    // If no filters are selected, show an alert and return
    if (!hasFilter) {
        alert("Please select at least one filter criteria before applying the filter.");
        return;
    }

    let formData = $("#filterForm").serialize();
    $.ajax({
        url: "fetch_data.php",
        type: "POST",
        data: formData,
        dataType: "json",
        success: function (response) {
            let table = `<table id='example2' class='table table-bordered'><thead>
                <tr>
                    <th>ID</th>
                    <th>Register Number</th>
                    <th>Student Name</th>
                    <th>DOB</th>
                    <th>Gender</th>
                    <th>Father's Name</th>
                    <th>Door No</th>
                    <th>Address Line 1</th>
                    <th>Address Line 2</th>
                    <th>Pincode</th>
                    <th>City</th>
                    <th>District</th>
                    <th>State</th>
                    <th>Institute Name</th>
                    <th>Degree</th>
                    <th>Joined Year</th>
                    <th>Completed Year</th>
                    <th>Mobile</th>
                    <th>Email</th>
                </tr></thead><tbody>`;

            response.forEach(row => {
                table += `<tr>
                    <td>${row.id}</td>
                    <td>${row.register_number}</td>
                    <td>${row.student_name}</td>
                    <td>${row.date_of_birth}</td>
                    <td>${row.gender}</td>
                    <td>${row.father_name}</td>
                    <td>${row.door_house_no}</td>
                    <td>${row.address_line1}</td>
                    <td>${row.address_line2}</td>
                    <td>${row.pincode}</td>
                    <td>${row.city}</td>
                    <td>${row.district}</td>
                    <td>${row.state}</td>
                    <td>${row.institute_name}</td>
                    <td>${row.completed_course}</td>
                    <td>${row.joined_year}</td>
                    <td>${row.completed_year}</td>
                    <td>${row.mobile_whatsapp}</td>
                    <td>${row.email_id}</td>
                </tr>`;
            });

            table += `</tbody></table>`;
            $("#resultsContainer").html(table);

            // Initialize DataTable AFTER inserting table
            $('#example2').DataTable({
                dom: 'Bfrtip',
                scrollX: true,
                autoWidth: false,
                buttons: ['copy', 'excel', 'pdf', 'print']
            });
        }
    });
}


    $("#applyFilter").click(fetchResults);
});
</script>
</body>
</html>
